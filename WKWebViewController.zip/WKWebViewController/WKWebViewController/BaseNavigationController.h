//
//  BaseNavigationController.h
//  BANYAN
//
//  Created by BANYAN on 2017/1/22.
//  Copyright © 2017年 GREEN BANYAN. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "RxWebViewNavigationViewController.h"

@interface BaseNavigationController : UINavigationController

@end
